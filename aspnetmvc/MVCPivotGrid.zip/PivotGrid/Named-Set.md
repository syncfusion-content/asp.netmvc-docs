---
layout: post
title: Named Set | PivotGrid | ASP.NET MVC | Syncfusion
description: named set
platform: ejmvc
control: PivotGrid
documentation: ug
---

#Named Set

I>This feature is applicable only for OLAP datasource at both client Mode and server Mode.

Named set is a multidimensional expression (MDX) that returns a set of dimension members, which can be created by combining cube data, arithmetic operators, numbers and functions. You can set Named Set option in PivotGrid by setting the `isNamedSets` property to true.

{% highlight C# %}

@Html.EJ().Pivot().PivotGrid("PivotGrid1").DataSource(dataSource => dataSource.Rows(rows => { rows.FieldName("[Date].[Fiscal]").Add(); }).Columns(columns => { columns.FieldName("[Core Product Group]").IsNamedSets(true).Add(); }).Values(values => { values.Measures(measures => { measures.FieldName("[Measures].[Internet Sales Amount]").Add(); }).Axis(AxisName.Column).Add(); }).Data("http://bi.syncfusion.com/olap/msmdpump.dll").Catalog("Adventure Works DW 2008 SE").Cube("Adventure Works"))

{% endhighlight %}

![](KPI_images/namedset.png)